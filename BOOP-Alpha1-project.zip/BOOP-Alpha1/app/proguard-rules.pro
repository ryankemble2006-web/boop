# Alpha 1 deliberately has no shrinking-specific rules.
